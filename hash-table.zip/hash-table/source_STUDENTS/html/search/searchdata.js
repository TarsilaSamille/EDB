var indexSectionsWithContent =
{
  0: "acdeghikmors~",
  1: "ahk",
  2: "a",
  3: "aceghiors~",
  4: "ehm",
  5: "o",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Amigos",
  6: "Páginas"
};


var searchData=
[
  ['student_3a_20társila_20samille_20santos_20da_20silveira_8',['Student: Társila Samille Santos da Silveira',['../index.html',1,'']]],
  ['selectionsort_9',['selectionsort',['../namespaceoa.html#a93cf65933919db9096bfeed2120da4d4',1,'oa']]],
  ['shellsort_10',['shellsort',['../namespaceoa.html#afc8e28a3d0a83354b39e54ec6093ff56',1,'oa']]],
  ['swap_11',['swap',['../namespaceoa.html#af094d5be85d6d0cbb82655a6479e377a',1,'oa']]]
];

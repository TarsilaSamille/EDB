var searchData=
[
  ['quicksort_19',['quicksort',['../namespaceoa.html#a63ac4f1a2e75b0ef6bec772570946018',1,'oa::quicksort(value_type *array, int size)'],['../namespaceoa.html#a0ad1cdeca6344ca8bb554a64cf619072',1,'oa::quicksort(value_type *array, int low, int high)']]]
];

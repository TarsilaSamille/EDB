var indexSectionsWithContent =
{
  0: "bimopqrsv",
  1: "o",
  2: "bimpqrs",
  3: "v",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions",
  3: "typedefs",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Functions",
  3: "Typedefs",
  4: "Pages"
};


var searchData=
[
  ['partition_18',['partition',['../namespaceoa.html#a38cd4945d7e8c9e305e4e30cfba8cc21',1,'oa']]]
];

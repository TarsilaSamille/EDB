var indexSectionsWithContent =
{
  0: "cdimprsv",
  1: "mv",
  2: "mv",
  3: "cdiprsv",
  4: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "typedefs",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Definições de tipos",
  4: "Páginas"
};

